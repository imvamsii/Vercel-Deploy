import Image1 from "../../assets/c1.jpg";
import Image2 from "../../assets/c2.jpg";
import Image4 from "../../assets/c3.jpg";
import Image11 from "../../assets/c11.jpg";
import Image12 from "../../assets/c4.jpg";


export const Data = [
    {
        id: 12,
        image: Image12, //AWS DEV
    },
    {
        id: 2,
        image: Image2, // DSA IN C++
    },
    {
        id: 4,
        image: Image4, // WEB DEV
    },
    {
        id: 1,
        image: Image1, // AWS CP
    },
    {
        id: 11,
        image: Image11, //AGILE
    },
];


//LLD, JAVA